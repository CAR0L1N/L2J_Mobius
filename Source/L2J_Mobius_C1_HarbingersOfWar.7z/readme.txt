L2J-Mobius Harbringers of War

JDK: https://www.mediafire.com/file/kb2nfx54wojys4f/bellsoft-jdk17.0.2%252B9-windows-amd64.msi
Eclipse: https://www.mediafire.com/file/dd2fj30rtvj33lz/eclipse-java-2023-03-R-win32-x86_64.zip

Client (password L2jMobius): https://drive.google.com/u/0/uc?id=1SE8meo4vFJDkWMLsVAGUGqCcZFUtZ0yy&export=download
System: https://mega.nz/#!Igt2TaqJ!nOS9UjNg8Mof7nUvmxN5V1TwYpU151UkyZVuG47TrwU

All provided download links are for personal use. Redistribution of these links is bannable.


Totally fun project!